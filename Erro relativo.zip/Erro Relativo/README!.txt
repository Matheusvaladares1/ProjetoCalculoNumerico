O código foi desenvolvido em C++ utilizando a IDE Dev C++.

Para realizar o teste, execute o arquivo executável "calcular", desta forma os dados presentes nos arquivos "dado.txt","previsao.txt" serão lidos pelo programa, que irá calcular e escrever os valores das médias móveis no arquivo "resultado-erro-relativo.txt" presente nesta pasta.