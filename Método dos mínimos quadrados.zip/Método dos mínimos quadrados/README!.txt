O código foi desenvolvido em C++ utilizando a IDE Dev C++.

Para realizar o teste, execute o arquivo executável "calcular", desta forma os dados presentes no arquivo "casos-acumulados.txt" serão lidos pelo programa, que irá calcular e escrever os valores de alfa1, alfa2, alfa3 e previsão nos seus respectivos arquivos texto presentes nesta pasta.