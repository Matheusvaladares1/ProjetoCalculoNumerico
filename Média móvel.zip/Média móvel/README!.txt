O código foi desenvolvido em C++ utilizando a IDE Dev C++.

Para realizar o teste, execute o arquivo executável "calcular", desta forma os dados presentes no arquivo "valores.txt" serão lidos pelo programa, que irá calcular e escrever os valores das médias móveis no arquivo "resultado.txt" presente nesta pasta.