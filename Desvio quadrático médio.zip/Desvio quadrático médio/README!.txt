O código foi desenvolvido em C++ utilizando a IDE Dev C++.

Para realizar o teste, execute o arquivo executável "calcular", desta forma os dados presentes nos arquivos "resultado-alfa1.txt","resultado-alfa2.txt","resultado-alfa3.txt" serão lidos pelo programa, que irá calcular e escrever os valores das médias móveis no arquivo "resultado-EQM.txt" presente nesta pasta.